import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/utils/format_utils.dart';
import '../../features/account/state/account_store.dart';
import '../../tokens/mapper/account_tokens.dart';
import '../../tokens/mapper/core_tokens.dart';

class AccountOverviewVm {
  final double totalReceivable;
  final double totalReceived;
  final double totalRemaining;
  final double? totalRatio;
  final List<AccountDeviceReceivable> deviceReceivables;

  const AccountOverviewVm({
    required this.totalReceivable,
    required this.totalReceived,
    required this.totalRemaining,
    required this.totalRatio,
    required this.deviceReceivables,
  });
}

class AccountOverviewCard extends StatelessWidget {
  const AccountOverviewCard({super.key, required this.vm});

  final AccountOverviewVm vm;

  @override
  Widget build(BuildContext context) {
    final items = _buildItems(vm.deviceReceivables);

    return Container(
      width: double.infinity,
      height: AccountTokens.overviewCardHeight,
      padding: const EdgeInsets.fromLTRB(
        AccountTokens.overviewCardPaddingLeft,
        AccountTokens.overviewCardPaddingTop,
        AccountTokens.overviewCardPaddingRight,
        AccountTokens.overviewCardPaddingBottom,
      ),
      decoration: BoxDecoration(
        color: SheetColors.background,
        border: Border.all(
          color: TimingColors.cardBorder,
          width: AccountTokens.overviewCardBorderWidth,
        ),
        borderRadius: BorderRadius.circular(AccountTokens.overviewCardRadius),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Center(
            child: Text(
              '总览',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                letterSpacing: AccountTokens.overviewTitleLetterSpacing,
              ),
            ),
          ),
          const Divider(
            height: AccountTokens.overviewDividerThickness,
            thickness: AccountTokens.overviewDividerThickness,
            color: TimingColors.divider,
          ),
          const SizedBox(height: AccountTokens.overviewMiddleTopGap),
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: AccountTokens.overviewLeftColumnWidth,
                  child: Align(
                    alignment: Alignment.topCenter,
                    child: SizedBox(
                      width: AccountTokens.overviewChartSize,
                      height: AccountTokens.overviewChartSize,
                      child: _OverviewDonut(items: items),
                    ),
                  ),
                ),
                const SizedBox(width: AccountTokens.overviewChartListGap),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(
                      AccountTokens.overviewRightPaddingLeft,
                      AccountTokens.overviewRightPaddingTop,
                      AccountTokens.overviewRightPaddingRight,
                      AccountTokens.overviewRightPaddingBottom,
                    ),
                    child:
                        items.isEmpty
                            ? const Text(
                              '暂无设备数据',
                              style: TextStyle(
                                fontSize: 12,
                                color: SheetColors.hint,
                              ),
                            )
                            : SingleChildScrollView(
                              physics: BouncingScrollPhysics(),
                              child: Column(
                                children: [
                                  for (final item in items) ...[
                                    _OverviewLegendRow(item: item),
                                    if (item != items.last)
                                      const SizedBox(
                                        height:
                                            AccountTokens.overviewLegendRowGap,
                                      ),
                                  ],
                                ],
                              ),
                            ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: AccountTokens.overviewPieTopGap),
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: AccountTokens.overviewLeftColumnWidth,
                  child: Align(
                    alignment: Alignment.topCenter,
                    child: SizedBox(
                      width: AccountTokens.overviewPieSize,
                      height: AccountTokens.overviewPieSize,
                      child: _OverviewPie(
                        received: vm.totalReceived,
                        remaining: vm.totalRemaining,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: AccountTokens.overviewChartListGap),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(
                      AccountTokens.overviewRightPaddingLeft,
                      AccountTokens.overviewRightPaddingTop,
                      AccountTokens.overviewRightPaddingRight,
                      AccountTokens.overviewRightPaddingBottom,
                    ),
                    child: Column(
                      children: [
                        const SizedBox(
                          height: AccountTokens.overviewSummaryTopPadding,
                        ),
                        _kv('总应收', FormatUtils.money(vm.totalReceivable)),
                        const SizedBox(height: 6),
                        _kv('已实收', FormatUtils.money(vm.totalReceived)),
                        const SizedBox(height: 6),
                        _kv('剩余应收', FormatUtils.money(vm.totalRemaining)),
                        const SizedBox(height: 6),
                        _kv('回款率', FormatUtils.percent1(vm.totalRatio)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  List<_DeviceReceivable> _buildItems(
    List<AccountDeviceReceivable> deviceReceivables,
  ) {
    final items = deviceReceivables
        .map(
          (e) => _DeviceReceivable(
            deviceId: e.deviceId,
            name: e.name,
            amount: e.amount,
          ),
        )
        .toList();

    final totalAmount = items.fold<double>(
      0,
      (sum, item) => sum + item.amount,
    );

    for (var i = 0; i < items.length; i++) {
      final color =
          AccountTokens.overviewChartPalette[
              i % AccountTokens.overviewChartPalette.length
          ];
      items[i] = items[i].copyWith(
        ratio: totalAmount <= 0 ? 0 : (items[i].amount / totalAmount),
        color: color,
      );
    }
    return items;
  }

  Widget _kv(String k, String v) {
    return Row(
      children: [
        Expanded(child: Text(k, style: const TextStyle(fontSize: 13))),
        Text(
          v,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w400,
          ),
        ),
      ],
    );
  }
}

class _DeviceReceivable {
  final int deviceId;
  final String name;
  final double amount;
  final double ratio;
  final Color color;

  const _DeviceReceivable({
    required this.deviceId,
    required this.name,
    required this.amount,
    this.ratio = 0,
    this.color = Colors.grey,
  });

  _DeviceReceivable copyWith({double? ratio, Color? color}) {
    return _DeviceReceivable(
      deviceId: deviceId,
      name: name,
      amount: amount,
      ratio: ratio ?? this.ratio,
      color: color ?? this.color,
    );
  }
}

class _OverviewLegendRow extends StatelessWidget {
  final _DeviceReceivable item;

  const _OverviewLegendRow({required this.item});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: AccountTokens.overviewLegendDotSize,
          height: AccountTokens.overviewLegendDotSize,
          decoration: BoxDecoration(
            color: item.color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: AccountTokens.overviewLegendDotGap),
        Expanded(
          child: Text(
            item.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: AccountTokens.overviewLegendNameSize,
              color: AppColors.textPrimary,
            ),
          ),
        ),
        Text(
          FormatUtils.money(item.amount),
          style: const TextStyle(
            fontSize: AccountTokens.overviewLegendValueSize,
            fontWeight: FontWeight.w400,
            color: AppColors.textPrimary,
          ),
        ),
      ],
    );
  }
}

class _OverviewDonut extends StatelessWidget {
  final List<_DeviceReceivable> items;

  const _OverviewDonut({required this.items});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _OverviewDonutPainter(items: items),
    );
  }
}

class _OverviewDonutPainter extends CustomPainter {
  final List<_DeviceReceivable> items;

  _OverviewDonutPainter({required this.items});

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius =
        (size.shortestSide - AccountTokens.overviewChartStroke) / 2;
    final rect = Rect.fromCircle(center: center, radius: radius);
    final paint =
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = AccountTokens.overviewChartStroke
          ..strokeCap = StrokeCap.butt;

    if (items.isEmpty) {
      paint.color = SheetColors.fieldBorder;
      canvas.drawArc(rect, 0, 2 * 3.1415926, false, paint);
      return;
    }

    var start = -3.1415926 / 2;
    for (final item in items) {
      final sweep = 2 * 3.1415926 * item.ratio;
      if (sweep <= 0) continue;
      paint.color = item.color;
      canvas.drawArc(rect, start, sweep, false, paint);
      start += sweep;
    }
  }

  @override
  bool shouldRepaint(covariant _OverviewDonutPainter oldDelegate) {
    return oldDelegate.items != items;
  }
}

class _OverviewPie extends StatelessWidget {
  final double received;
  final double remaining;

  const _OverviewPie({required this.received, required this.remaining});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _OverviewPiePainter(received: received, remaining: remaining),
    );
  }
}

class _OverviewPiePainter extends CustomPainter {
  final double received;
  final double remaining;

  _OverviewPiePainter({required this.received, required this.remaining});

  @override
  void paint(Canvas canvas, Size size) {
    final total = (received + remaining);
    final receivedRatio = total <= 0 ? 0.0 : (received / total);
    final remainingRatio = total <= 0 ? 0.0 : (remaining / total);

    final center = size.center(Offset.zero);
    final radius = size.shortestSide / 2;
    final rect = Rect.fromCircle(center: center, radius: radius);
    final paint = Paint()..style = PaintingStyle.fill;

    if (total <= 0) {
      paint.color = SheetColors.fieldBorder;
      canvas.drawCircle(center, radius, paint);
      return;
    }

    final gap =
        (receivedRatio <= 0 || remainingRatio <= 0)
            ? 0.0
            : AccountTokens.overviewPieGapRadians;
    var start = -3.1415926 / 2;

    void drawSlice({
      required double ratio,
      required Color color,
      required String label,
    }) {
      final sweep = 2 * 3.1415926 * ratio;
      if (sweep <= 0) return;
      final drawSweep = (sweep - gap).clamp(0.0, sweep);
      paint.color = color;
      canvas.drawArc(rect, start, drawSweep, true, paint);

      if (ratio >= AccountTokens.overviewPieLabelMinRatio) {
        final mid = start + sweep / 2;
        final labelRadius = radius * AccountTokens.overviewPieLabelRadiusRatio;
        final offset = Offset(
          center.dx + labelRadius * math.cos(mid),
          center.dy + labelRadius * math.sin(mid),
        );
        final painter = TextPainter(
          text: TextSpan(
            text: label,
            style: const TextStyle(
              fontSize: AccountTokens.overviewPieLabelSize,
              fontWeight: AccountTokens.overviewPieLabelWeight,
              color: Colors.white,
            ),
          ),
          textAlign: TextAlign.center,
          textDirection: TextDirection.ltr,
        )..layout();
        final textOffset = offset -
            Offset(painter.width / 2, painter.height / 2);
        painter.paint(canvas, textOffset);
      }

      start += sweep;
    }

    drawSlice(
      ratio: remainingRatio,
      color: AccountTokens.overviewPieRemaining,
      label: '${(remainingRatio * 100).round()}%',
    );

    drawSlice(
      ratio: receivedRatio,
      color: AccountTokens.overviewPieReceived,
      label: '${(receivedRatio * 100).round()}%',
    );
  }

  @override
  bool shouldRepaint(covariant _OverviewPiePainter oldDelegate) {
    return oldDelegate.received != received ||
        oldDelegate.remaining != remaining;
  }
}
