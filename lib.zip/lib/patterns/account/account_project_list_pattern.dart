import 'package:flutter/material.dart';

import '../../core/foundation/radius.dart' as foundation_radius;
import '../../core/foundation/spacing.dart';
import '../../core/utils/format_utils.dart';
import '../../features/account/state/account_store.dart';
import '../../tokens/mapper/account_tokens.dart';
import '../../tokens/mapper/core_tokens.dart';

class AccountProjectList extends StatelessWidget {
  const AccountProjectList({
    super.key,
    required this.projects,
    required this.onTap,
  });

  final List<AccountProjectVM> projects;
  final ValueChanged<AccountProjectVM> onTap;

  String _priceText(AccountProjectVM p) {
    final rate = p.minRate;
    if (rate == null) return '单价：—';
    return p.isMultiDevice
        ? '单价：${FormatUtils.money(rate)}（多设备）'
        : '单价：${FormatUtils.money(rate)}';
  }

  @override
  Widget build(BuildContext context) {
    if (projects.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: AppSpace.xl),
        child: Center(child: Text('暂无项目（计时页有记录后将自动出现）')),
      );
    }

    return Column(
      children: [
        for (final p in projects) ...[
          Container(
            margin: const EdgeInsets.only(bottom: AppSpace.md),
            decoration: BoxDecoration(
              color: SheetColors.background,
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(
                AccountTokens.projectCardRadius,
              ),
            ),
            child: InkWell(
              borderRadius: BorderRadius.circular(
                AccountTokens.projectCardRadius,
              ),
              onTap: () => onTap(p),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 12,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Text(
                            p.displayName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 18,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          FormatUtils.date(p.minYmd),
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey.shade700,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: SpaceTokens.sectionGap),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppSpace.sm,
                        vertical: AppSpace.xs,
                      ),
                      decoration: BoxDecoration(
                        color: SheetColors.fieldBackground,
                        borderRadius: BorderRadius.circular(
                          foundation_radius.AppRadius.pill,
                        ),
                      ),
                      child: Text(
                        _priceText(p),
                        style: const TextStyle(
                          fontSize: 14,
                        ),
                      ),
                    ),
                    const SizedBox(height: SpaceTokens.sectionGap),
                    Row(
                      children: [
                        Text(
                          '${FormatUtils.percent1(p.ratio)} 实收',
                          style: const TextStyle(
                            fontSize: 14,
                          ),
                        ),
                        const Spacer(),
                        Text(
                          '余:${FormatUtils.money(p.remaining)} / ${FormatUtils.money(p.receivable)}',
                          style: const TextStyle(
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(
                        foundation_radius.AppRadius.pill,
                      ),
                      child: LinearProgressIndicator(
                        minHeight: 10,
                        value: (p.ratio ?? 0).clamp(0, 1),
                        backgroundColor: SheetColors.fieldBackground,
                        valueColor: const AlwaysStoppedAnimation<Color>(
                          TimingColors.chartIncome,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }
}
