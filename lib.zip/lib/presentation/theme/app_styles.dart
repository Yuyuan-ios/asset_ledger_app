import 'package:flutter/material.dart';
import 'tokens/core_tokens.dart';

class AppDecorations {
  static BoxDecoration cardBox() => BoxDecoration(
    color: AppColors.cardFill,
    borderRadius: BorderRadius.circular(AppRadius.card),
    border: Border.all(color: AppColors.cardBorder),
  );
}
