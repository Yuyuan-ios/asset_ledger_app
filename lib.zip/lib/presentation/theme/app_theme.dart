import 'package:flutter/material.dart';
import 'tokens/core_tokens.dart';

class AppTheme {
  static ThemeData light() {
    final base = ThemeData(
      useMaterial3: true,
      colorSchemeSeed: AppColors.brand,
    );
    final cs = base.colorScheme.copyWith(
      primary: AppColors.sheetAction,
      onPrimary: AppColors.sheetActionOn,
      secondary: AppColors.sheetAction,
      surface: AppColors.sheetBackground,
    );

    return base.copyWith(
      colorScheme: cs,
      scaffoldBackgroundColor: AppColors.scaffoldBg,
      dividerColor: AppColors.divider,
      dialogTheme: const DialogThemeData(
        backgroundColor: AppColors.sheetBackground,
        surfaceTintColor: Colors.transparent,
        insetPadding: EdgeInsets.symmetric(
          horizontal: DialogTokens.insetHorizontal,
          vertical: DialogTokens.insetVertical,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(DialogTokens.radius)),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: AppColors.sheetAction,
          foregroundColor: AppColors.sheetActionOn,
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(foregroundColor: AppColors.sheetAction),
      ),

      // 全局 Card 风格（你说“卡片颜色不动”，以后就只改 Token）
      cardTheme: CardThemeData(
        color: AppColors.cardFill,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(AppRadius.card)),
          side: BorderSide(color: AppColors.cardBorder),
        ),
      ),

      // 统一 AppBar 风格（你现在主壳没 AppBar，但页面内可能会用）
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: AppColors.textPrimary,
      ),
    );
  }
}
