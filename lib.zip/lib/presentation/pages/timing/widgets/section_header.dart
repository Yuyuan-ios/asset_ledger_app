import 'package:flutter/material.dart';
import '../../../theme/app_tokens.dart';

class SectionHeader extends StatelessWidget {
  const SectionHeader({super.key});

  @override
  Widget build(BuildContext context) {
    // 先占位：后面再按 Figma 像素改
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppSpace.pageHPadding,
        AppSpace.pageVPadding,
        AppSpace.pageHPadding,
        0,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            '计时',
            style: const TextStyle(
              fontSize: AppText.title,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          FilledButton(onPressed: () {}, child: const Text('+ 新建')),
        ],
      ),
    );
  }
}
