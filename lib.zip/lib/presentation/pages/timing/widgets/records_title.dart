import 'package:flutter/material.dart';

class RecordsTitle extends StatelessWidget {
  final int count;
  const RecordsTitle({super.key, required this.count});

  @override
  Widget build(BuildContext context) {
    final style = Theme.of(context).textTheme.titleMedium;

    return Text(
      '最近记录（$count）',
      style: style?.copyWith(fontWeight: FontWeight.w900),
    );
  }
}
