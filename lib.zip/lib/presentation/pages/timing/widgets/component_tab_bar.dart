import 'package:flutter/material.dart';
import 'package:asset_ledger/presentation/theme/app_tokens.dart';

class ComponentTabBar extends StatelessWidget {
  const ComponentTabBar({super.key});

  @override
  Widget build(BuildContext context) {
    // 先占位：后面按 Figma 的 TabBar 做成真实结构
    return SafeArea(
      top: false,
      child: Container(
        height: AppSpace.tabBarHeight,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: AppColors.divider)),
          color: AppColors.cardFill,
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Icon(Icons.timer),
            Icon(Icons.local_gas_station),
            Icon(Icons.receipt_long),
            Icon(Icons.build),
            Icon(Icons.settings),
          ],
        ),
      ),
    );
  }
}
