import 'package:flutter/material.dart';

import '../../../theme/tokens/core_tokens.dart';
import '../../../theme/tokens/timing_tokens.dart';

class DigitWheelField extends StatefulWidget {
  const DigitWheelField({
    super.key,
    required this.title,
    required this.controller,
    required this.onChanged,
  });

  final String title;
  final TextEditingController controller;
  final ValueChanged<double> onChanged;

  @override
  State<DigitWheelField> createState() => _DigitWheelFieldState();
}

class _DigitWheelFieldState extends State<DigitWheelField> {
  late List<int> _digits;
  bool _syncingController = false;

  @override
  void initState() {
    super.initState();
    _digits = _digitsFromValue(_parse(widget.controller.text));
    widget.controller.addListener(_onControllerChanged);
  }

  @override
  void didUpdateWidget(covariant DigitWheelField oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.removeListener(_onControllerChanged);
      widget.controller.addListener(_onControllerChanged);
      _digits = _digitsFromValue(_parse(widget.controller.text));
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onControllerChanged);
    super.dispose();
  }

  void _onControllerChanged() {
    if (_syncingController) return;
    final next = _digitsFromValue(_parse(widget.controller.text));
    if (_sameDigits(next, _digits)) return;
    setState(() => _digits = next);
  }

  bool _sameDigits(List<int> a, List<int> b) {
    if (a.length != b.length) return false;
    for (var i = 0; i < a.length; i++) {
      if (a[i] != b[i]) return false;
    }
    return true;
  }

  double _parse(String text) => double.tryParse(text.trim()) ?? 0.0;

  List<int> _digitsFromValue(double value) {
    final tenths = (value * 10).round().clamp(0, 999999);
    final intPart = tenths ~/ 10;
    final decimal = tenths % 10;
    return <int>[
      (intPart ~/ 10000) % 10,
      (intPart ~/ 1000) % 10,
      (intPart ~/ 100) % 10,
      (intPart ~/ 10) % 10,
      intPart % 10,
      decimal,
    ];
  }

  double _valueFromDigits(List<int> digits) {
    final intPart =
        digits[0] * 10000 +
        digits[1] * 1000 +
        digits[2] * 100 +
        digits[3] * 10 +
        digits[4];
    return intPart + digits[5] / 10.0;
  }

  void _onDigitChanged(int index, int digit) {
    final next = [..._digits]..[index] = digit;
    final value = _valueFromDigits(next);

    _syncingController = true;
    widget.controller.text = value.toStringAsFixed(1);
    _syncingController = false;

    setState(() => _digits = next);
    widget.onChanged(value);
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final groupWidth =
            TimingTokens.meterCellSize * 6 +
            TimingTokens.meterGap * 4 +
            TimingTokens.meterDecimalGap * 2 +
            TimingTokens.meterDotSlotWidth;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: SizedBox(
                width: groupWidth,
                child: SizedBox(
                  height: TimingTokens.meterLabelHeight,
                  child: Text(
                    widget.title,
                    style: const TextStyle(
                      fontSize: TimingTokens.meterLabelSize,
                      color: AppColors.sheetTextPrimary,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: TimingTokens.meterLabelBottomGap),
            Listener(
              onPointerDown: (_) =>
                  FocusManager.instance.primaryFocus?.unfocus(),
              child: Container(
                height: TimingTokens.meterContainerHeight,
                padding: const EdgeInsets.symmetric(
                  horizontal: TimingTokens.meterContainerHPadding,
                  vertical: TimingTokens.meterContainerVPadding,
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(
                    TimingTokens.meterContainerRadius,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    for (int i = 0; i < 5; i++) ...[
                      _DigitWheelCell(
                        value: _digits[i],
                        onChanged: (v) => _onDigitChanged(i, v),
                      ),
                      if (i < 4) const SizedBox(width: TimingTokens.meterGap),
                    ],
                    const SizedBox(width: TimingTokens.meterDecimalGap),
                    const SizedBox(
                      width: TimingTokens.meterDotSlotWidth,
                      child: Center(
                        child: Text(
                          '.',
                          style: TextStyle(
                            fontSize: TimingTokens.meterDotSize,
                            fontWeight: FontWeight.w700,
                            color: AppColors.sheetTextPrimary,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: TimingTokens.meterDecimalGap),
                    _DigitWheelCell(
                      value: _digits[5],
                      onChanged: (v) => _onDigitChanged(5, v),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _DigitWheelCell extends StatefulWidget {
  const _DigitWheelCell({required this.value, required this.onChanged});

  final int value;
  final ValueChanged<int> onChanged;

  @override
  State<_DigitWheelCell> createState() => _DigitWheelCellState();
}

class _DigitWheelCellState extends State<_DigitWheelCell> {
  late FixedExtentScrollController _controller;
  bool _programmaticScrolling = false;

  @override
  void initState() {
    super.initState();
    _controller = FixedExtentScrollController(initialItem: widget.value);
  }

  @override
  void didUpdateWidget(covariant _DigitWheelCell oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.value != widget.value) {
      if (!_controller.hasClients) {
        _programmaticScrolling = true;
        _controller.jumpToItem(widget.value);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _programmaticScrolling = false;
        });
        return;
      }

      final current = _controller.selectedItem % 10;
      if (current == widget.value) return;

      _programmaticScrolling = true;
      _controller
          .animateToItem(
            widget.value,
            duration: const Duration(
              milliseconds: TimingTokens.meterRollbackAnimMs,
            ),
            curve: Curves.easeOutCubic,
          )
          .whenComplete(() {
            _programmaticScrolling = false;
          });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: TimingTokens.meterCellSize,
      child: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              color: AppColors.sheetBackground,
              borderRadius: BorderRadius.circular(TimingTokens.digitCellRadius),
              border: Border.all(
                color: AppColors.sheetFieldBorder,
                width: TimingTokens.digitCellBorderWidth,
              ),
            ),
            child: ListWheelScrollView.useDelegate(
              controller: _controller,
              itemExtent: TimingTokens.meterItemExtent,
              diameterRatio: TimingTokens.meterWheelDiameterRatio,
              squeeze: 1,
              physics: const FixedExtentScrollPhysics(),
              onSelectedItemChanged: (index) {
                if (_programmaticScrolling) return;
                final next = index % 10;
                if (next == widget.value) return;
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (!mounted) return;
                  widget.onChanged(next);
                });
              },
              childDelegate: ListWheelChildLoopingListDelegate(
                children: List.generate(
                  10,
                  (i) => Center(
                    child: Text(
                      '$i',
                      style: TextStyle(
                        fontSize: i == widget.value
                            ? TimingTokens.meterSelectedTextSize
                            : TimingTokens.meterUnselectedTextSize,
                        color: i == widget.value
                            ? AppColors.sheetTextPrimary
                            : AppColors.sheetTextPrimary.withValues(alpha: 0.6),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          IgnorePointer(
            child: Center(
              child: Container(
                height: TimingTokens.meterItemExtent,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(
                    TimingTokens.digitOverlayRadius,
                  ),
                  border: Border.all(
                    color: AppColors.sheetDigitHighlight.withValues(alpha: 0.7),
                    width: TimingTokens.digitHighlightBorderWidth,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
