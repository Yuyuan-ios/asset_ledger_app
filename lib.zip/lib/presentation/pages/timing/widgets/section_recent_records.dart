import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:asset_ledger/presentation/theme/app_tokens.dart';

import '../../../../models/timing_record.dart';
import '../../../../store/device_store.dart';

class SectionRecentRecords extends StatelessWidget {
  final List<TimingRecord> records;
  final DeviceStore deviceStore;

  const SectionRecentRecords({
    super.key,
    required this.records,
    required this.deviceStore,
  });

  @override
  Widget build(BuildContext context) {
    // 先占位：后面替换成你已经有的 record_list_tile 等
    if (records.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: AppSpace.md),
        child: Text('暂无记录'),
      );
    }

    return Column(
      children: List.generate(
        records.length,
        (i) =>
            ListTile(title: Text('记录 #$i'), subtitle: const Text('后面换成真实字段')),
      ),
    );
  }
}
