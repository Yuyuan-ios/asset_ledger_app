import 'package:flutter/material.dart';
import 'package:asset_ledger/presentation/theme/app_tokens.dart';

class CardMainChart extends StatelessWidget {
  const CardMainChart({super.key});

  @override
  Widget build(BuildContext context) {
    // 先占位：后面换成你真正的图表
    return Card(
      child: SizedBox(
        height: AppSpace.chartHeight,
        width: double.infinity,
        child: Center(
          child: Text(
            'Chart Placeholder',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ),
      ),
    );
  }
}
