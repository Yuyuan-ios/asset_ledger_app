// =====================================================================
// ============================== 一、导入依赖库 ==============================
// =====================================================================

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

// 模型 / Store
import '../../../models/timing_record.dart';
import '../../../store/timing_store.dart';
import '../../../store/device_store.dart';

// UI 组件 / 工具
import '../../widgets/device_avatar.dart';
import '../../widgets/record_list_tile.dart';
import 'widgets/records_title.dart';
import 'widgets/timing_status_bar.dart';
import 'widgets/section_header.dart';
import 'widgets/card_main_chart.dart';
import 'widgets/section_recent_records.dart';
import 'widgets/component_tab_bar.dart';
import 'widgets/overlay_tab_bar.dart';
import '../../utils/device_label.dart';
import '../../utils/format_utils.dart';
import '../../sheets/app_bottom_sheet_shell.dart';
import '../../content/timing_detail_content.dart';

import '../../theme/app_tokens.dart';

// =====================================================================
// ============================== 二、常量定义 ==============================
// =====================================================================

const EdgeInsets kTimingPagePadding = EdgeInsets.all(16);
const double kSectionGap = 12.0;

// =====================================================================
// ============================== 三、页面入口 ==============================
// =====================================================================

class TimingPage extends StatefulWidget {
  const TimingPage({super.key});

  @override
  State<TimingPage> createState() => _TimingPageState();
}

// =====================================================================
// ============================== 四、State：只做页面级交互 ==============================
// =====================================================================

class _TimingPageState extends State<TimingPage> {
  // -------------------------------------------------------------------
  // 4.1 生命周期：页面打开后加载数据
  // 说明：
  // - 你之前有“MainPage 统一加载”的设计也可以保留
  // - 这里写 loadAll 是“兜底”：确保单独打开本页也能正常显示
  // -------------------------------------------------------------------
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      // timing / device 都兜底加载一次（已加载不会影响功能，只是一次查询）
      await context.read<DeviceStore>().loadAll();
      await context.read<TimingStore>().loadAll();
    });
  }

  // -------------------------------------------------------------------
  // 4.2 通用提示
  // -------------------------------------------------------------------
  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), duration: const Duration(seconds: 2)),
    );
  }

  Widget _buildHeader() {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
      child: Row(
        children: [
          Text(
            '计时',
            style: theme.textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.w900,
              height: 1.1,
            ),
          ),
          const Spacer(),
          FilledButton(
            onPressed: () => _openTimingEditor(),
            style: const ButtonStyle(
              // ✅ 不写颜色：交给全局 FilledButtonTheme
              shape: WidgetStatePropertyAll(StadiumBorder()),
              padding: WidgetStatePropertyAll(
                EdgeInsets.symmetric(horizontal: 18, vertical: 2),
              ),
            ),
            child: Text(
              '+ 新建',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // -------------------------------------------------------------------
  // 4.3 设备展示名（兼容：设备缺失 / 已停用）
  // -------------------------------------------------------------------
  String _deviceNameById(int id) {
    final d = context.read<DeviceStore>().findById(id);
    if (d == null) return '未知设备($id)';

    // ✅ 防御式：旧模型可能没有 isActive 字段
    bool isActive = true;
    try {
      // ignore: avoid_dynamic_calls
      isActive = (d as dynamic).isActive == true;
    } catch (_) {
      isActive = true;
    }

    if (!isActive) return '${d.name}（已停用）';
    return d.name;
  }

  // -------------------------------------------------------------------
  // 4.4 打开底部弹窗：新建/编辑（内容负责表单；Page 负责保存+toast+pop）
  // -------------------------------------------------------------------
  Future<void> _openTimingEditor({TimingRecord? editing}) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.transparent,
      builder: (_) {
        return AppBottomSheetShell(
          title: editing == null ? '新建计时' : '编辑计时',
          child: Padding(
            padding: EdgeInsets.only(
              left: 16,
              right: 16,
              top: 12,
              bottom: 16 + MediaQuery.of(context).viewInsets.bottom,
            ),
            child: TimingDetailContent(
              editing: editing,

              // 取消：直接关弹窗
              onCancel: () => Navigator.of(context).pop(),

              // toast：统一走你页面的 _toast
              onToast: _toast,

              // ✅ 保存流程：Page 负责（与 Account 统一）
              onSubmit: (record) async {
                final store = context.read<TimingStore>();
                await store.save(record);

                if (!mounted) return;

                if (store.error != null) {
                  _toast('保存失败：${store.error}');
                  return;
                }

                _toast('已保存');
                Navigator.of(context).pop(); // ✅ 保存成功后关闭弹窗
              },
            ),
          ),
        );
      },
    );
  }

  // -------------------------------------------------------------------
  // 4.5 删除：确认 + Store.deleteById
  // -------------------------------------------------------------------
  Future<void> _deleteRecord(TimingRecord r) async {
    if (r.id == null) {
      _toast('该记录缺少 id，无法删除');
      return;
    }

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('确认删除？'),
          content: Text(
            '设备：${_deviceNameById(r.deviceId)}\n'
            '日期：${FormatUtils.date(r.startDate)}\n'
            '联系人：${r.contact}\n'
            '工地：${r.site}\n\n'
            '⚠️ 删除后不可恢复',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text('删除'),
            ),
          ],
        );
      },
    );

    if (ok != true) return;

    final store = context.read<TimingStore>();
    await store.deleteById(r.id!);

    if (!mounted) return;

    if (store.error != null) {
      _toast('删除失败：${store.error}');
    } else {
      _toast('已删除');
    }
  }

  // =====================================================================
  // ============================== 五、UI：统计卡片（占位） ==============================
  // =====================================================================

  Widget _buildChartPlaceholder() {
    final theme = Theme.of(context);
    final dividerColor = theme.dividerColor; // 你在 Theme 里统一的分割线色

    return Card(
      // ✅ 这里会自动吃你 ThemeData.cardTheme 的 color/shape/elevation
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // ① 年切换：<  2026年  >
            Row(
              children: [
                IconButton(
                  visualDensity: VisualDensity.compact,
                  onPressed: () => _toast('后续：切换上一年'),
                  icon: const Icon(Icons.chevron_left),
                ),
                Expanded(
                  child: Center(
                    child: Text(
                      '2026年',
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  onPressed: () => _toast('后续：切换下一年'),
                  icon: const Icon(Icons.chevron_right),
                ),
              ],
            ),

            Divider(height: 12, thickness: 1, color: dividerColor),

            // ② 图表区域（占位）
            SizedBox(
              height: 220,
              child: Stack(
                children: [
                  Positioned(
                    left: 14,
                    bottom: 44,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        _barGroup(greenHeight: 150, blackHeight: 24),
                        const SizedBox(width: 22),
                        _barGroup(greenHeight: 150, blackHeight: 90),
                      ],
                    ),
                  ),

                  // 月份行：动态生成（以后真实图表一一对应）
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 14,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: List.generate(12, (i) {
                        final m = i + 1;
                        return Text(
                          '$m月',
                          style: theme.textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.w500,
                          ),
                        );
                      }),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 8),

            // ③ 图例（两列：第一行“色块+文字”，第二行“金额”）
            Row(
              children: [
                Expanded(
                  child: _legendColumn(
                    color: AppColors.income, // ✅ 放 Token 里
                    label: '收入',
                    value: '¥1000000',
                  ),
                ),
                Expanded(
                  child: _legendColumn(
                    color: AppColors.expense, // ✅ 放 Token 里
                    label: '支出',
                    value: '¥500000',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  /// 一组柱：绿色（收入）+ 黑色（支出）
  Widget _barGroup({required double greenHeight, required double blackHeight}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Container(
          width: 12,
          height: greenHeight,
          decoration: BoxDecoration(
            color: AppColors.income,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 6),
        Container(
          width: 10,
          height: blackHeight,
          decoration: BoxDecoration(
            color: AppColors.expense,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ],
    );
  }

  /// 图例一列：第一行 色块+label；第二行 value（金额）
  Widget _legendColumn({
    required Color color,
    required String label,
    required String value,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 14,
              height: 14,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(3),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          value,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
        ),
      ],
    );
  }

  // =====================================================================
  // ============================== 六、UI：列表 ==============================
  // =====================================================================

  Widget _buildRecentList({
    required List<TimingRecord> records,
    required DeviceStore deviceStore,
  }) {
    if (records.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 22),
        child: Center(child: Text('暂无记录（点击右上角 + 新建）')),
      );
    }

    // 最新在前
    final reversed = records.reversed.toList();

    return ListView.separated(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: reversed.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, index) {
        final r = reversed[index];
        final device = deviceStore.findById(r.deviceId);

        final deviceName = _deviceNameById(r.deviceId);
        final titleDevice = DeviceLabel.indexOnly(deviceName);
        final typeText = (r.type == TimingType.hours) ? '工时' : '租金';

        return RecordListTile(
          dense: true,
          leading: device == null
              ? const CircleAvatar(radius: 18, child: Text('?'))
              : DeviceAvatar(device: device),
          onTap: () => _openTimingEditor(editing: r),
          title: '$titleDevice · ${FormatUtils.date(r.startDate)} · $typeText',
          subtitle: '${r.contact} · ${r.site}',
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${FormatUtils.meter(r.startMeter)} → ${FormatUtils.meter(r.endMeter)}',
                    style: const TextStyle(fontSize: 12),
                  ),
                  Text(
                    r.type == TimingType.rent
                        ? '${FormatUtils.hours(r.hours)} · ${FormatUtils.money(r.income)}'
                        : FormatUtils.hours(r.hours),
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 6),
              IconButton(
                tooltip: '删除',
                icon: const Icon(Icons.delete_outline, size: 20),
                onPressed: (r.id == null) ? null : () => _deleteRecord(r),
              ),
            ],
          ),
        );
      },
    );
  }

  // =====================================================================
  // ============================== 七、主 build：统计 + 列表（整页） ==============================
  // =====================================================================

  @override
  Widget build(BuildContext context) {
    final timingStore = context.watch<TimingStore>();
    final deviceStore = context.watch<DeviceStore>();

    final loading = timingStore.loading || deviceStore.loading;
    final err = timingStore.error ?? deviceStore.error;
    final records = timingStore.records;

    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            // 主体 + 底部 Tab
            Column(
              children: [
                const SectionHeader(), // 原 _buildHeader()

                Expanded(
                  child: SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppSpace.pageHPadding,
                        vertical: AppSpace.pageVPadding,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // 状态条（建议独立成小组件）
                          TimingStatusBar(loading: loading, error: err),

                          const CardMainChart(), // 原 _buildChartPlaceholder()
                          const SizedBox(height: AppSpace.lg),

                          RecordsTitle(
                            count: records.length,
                          ), // 原 Text('最近记录...')
                          const SizedBox(height: AppSpace.sm),

                          SectionRecentRecords(
                            records: records,
                            deviceStore: deviceStore,
                          ),

                          const SizedBox(height: AppSpace.xl),
                        ],
                      ),
                    ),
                  ),
                ),

                const ComponentTabBar(), // 底部固定
              ],
            ),

            // 遮罩（如果你要 TabBar 弹层时显示）
            const OverlayTabBar(), // 先留着，内部可以按需 return SizedBox.shrink()
          ],
        ),
      ),
    );
  }
}
