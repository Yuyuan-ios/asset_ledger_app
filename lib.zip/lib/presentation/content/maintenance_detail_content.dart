// ==============================================================================
// 📁 文件说明：维保弹窗内容 (maintenance_detail_content.dart)
//
// 设计目标：
// 1) 作为 BottomSheet 的内容区域（配合 AppBottomSheetShell 使用）
// 2) 负责“新增/编辑维保”的表单与校验
// 3) 不直接操作 Store / 不 pop：统一走回调（与 Account 统一）
// ==============================================================================

// =====================================================================
// ============================== 一、导入依赖库 ==============================
// =====================================================================

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/maintenance_record.dart';
import '../../models/device.dart';

import '../../store/device_store.dart';

import '../../presentation/utils/format_utils.dart';
import '../../presentation/widgets/device_picker.dart';

// =====================================================================
// ============================== 二、Content Widget ==============================
// =====================================================================

class MaintenanceDetailContent extends StatefulWidget {
  const MaintenanceDetailContent({
    super.key,
    this.editing,
    required this.onCancel,
    required this.onToast,
    required this.onSubmit,
  });

  /// editing != null：编辑；否则新建
  final MaintenanceRecord? editing;

  /// 取消（由 Page 负责 pop）
  final VoidCallback onCancel;

  /// toast（统一走 Page 的 toast 体系）
  final void Function(String msg) onToast;

  /// 提交（Content 只组装 MaintenanceRecord）
  final Future<void> Function(MaintenanceRecord record) onSubmit;

  @override
  State<MaintenanceDetailContent> createState() =>
      _MaintenanceDetailContentState();
}

class _MaintenanceDetailContentState extends State<MaintenanceDetailContent> {
  // -------------------------------------------------------------------
  // 2.1 表单控制器
  // -------------------------------------------------------------------

  final _dateCtrl = TextEditingController();
  final _itemCtrl = TextEditingController();
  final _amountCtrl = TextEditingController(text: '0.0');
  final _noteCtrl = TextEditingController();

  // -------------------------------------------------------------------
  // 2.2 表单状态
  // -------------------------------------------------------------------

  int? _selectedDeviceId;

  /// 公共支出：deviceId = null
  bool _isPublicExpense = false;

  bool _submitting = false;

  // =====================================================================
  // ============================== 三、生命周期 ==============================
  // =====================================================================

  @override
  void initState() {
    super.initState();

    final editing = widget.editing;

    if (editing == null) {
      _dateCtrl.text = FormatUtils.todayYmd();
      _isPublicExpense = false;
      _selectedDeviceId = null;
      _itemCtrl.clear();
      _amountCtrl.text = '0.0';
      _noteCtrl.clear();
    } else {
      _dateCtrl.text = editing.ymd.toString();
      _itemCtrl.text = editing.item;
      _amountCtrl.text = editing.amount.toStringAsFixed(1);
      _noteCtrl.text = editing.note ?? '';

      _isPublicExpense = (editing.deviceId == null);
      _selectedDeviceId = editing.deviceId;
    }
  }

  @override
  void dispose() {
    _dateCtrl.dispose();
    _itemCtrl.dispose();
    _amountCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  // =====================================================================
  // ============================== 四、工具：解析/校验 ==============================
  // =====================================================================

  int? _parseYmd(String s) {
    final t = s.trim();
    if (t.length != 8) return null;
    return int.tryParse(t);
  }

  double? _parseAmount(String s) => double.tryParse(s.trim());

  /// 设备 active 判定（兼容旧模型没 isActive）
  bool _deviceIsActive(Device d) {
    try {
      // ignore: avoid_dynamic_calls
      return (d as dynamic).isActive == true;
    } catch (_) {
      return true;
    }
  }

  Future<void> _submit() async {
    if (_submitting) return;

    // 1) 日期
    final ymd = _parseYmd(_dateCtrl.text);
    if (ymd == null || ymd <= 0) {
      widget.onToast('保存失败：日期必须是 YYYYMMDD（例如 20260208）');
      return;
    }

    // 2) 事项
    final item = _itemCtrl.text.trim();
    if (item.isEmpty) {
      widget.onToast('保存失败：事项必填');
      return;
    }

    // 3) 金额
    final amount = _parseAmount(_amountCtrl.text);
    if (amount == null) {
      widget.onToast('保存失败：金额格式不正确');
      return;
    }
    if (amount <= 0) {
      widget.onToast('保存失败：金额应大于 0');
      return;
    }

    // 4) 设备 / 公共支出
    int? deviceId;
    if (_isPublicExpense) {
      deviceId = null;
    } else {
      deviceId = _selectedDeviceId;
      if (deviceId == null) {
        widget.onToast('保存失败：请选择设备，或切换为“公共支出”');
        return;
      }

      // 新建态：不允许选停用设备（编辑态允许回显历史）
      final device = context.read<DeviceStore>().findById(deviceId);
      if (device == null) {
        widget.onToast('设备不存在（id=$deviceId），请先去设备页检查');
        return;
      }
      if (widget.editing == null && !_deviceIsActive(device)) {
        widget.onToast('该设备已停用，不能用于新建维保记录');
        return;
      }
    }

    // 5) 备注（可空）
    final note = _noteCtrl.text.trim();

    final record = MaintenanceRecord(
      id: widget.editing?.id,
      deviceId: deviceId,
      ymd: ymd,
      item: item,
      amount: amount,
      note: note.isEmpty ? null : note,
    );

    setState(() => _submitting = true);
    await widget.onSubmit(record);
    if (mounted) setState(() => _submitting = false);
  }

  // =====================================================================
  // ============================== 五、UI 小组件 ==============================
  // =====================================================================

  Widget _field({
    required TextEditingController controller,
    required String label,
    TextInputType? keyboardType,
    String? hint,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        border: const OutlineInputBorder(),
        isDense: true,
      ),
    );
  }

  // =====================================================================
  // ============================== 六、build：表单内容 ==============================
  // =====================================================================

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // 1) 公共支出开关（置顶）
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('公共支出（不属于任何设备）'),
          value: _isPublicExpense,
          onChanged: (v) {
            setState(() {
              _isPublicExpense = v;
              if (v) _selectedDeviceId = null;
            });
          },
        ),
        const SizedBox(height: 12),

        // 2) 设备（公共支出时灰掉）
        IgnorePointer(
          ignoring: _isPublicExpense,
          child: Opacity(
            opacity: _isPublicExpense ? 0.5 : 1.0,
            child: DevicePicker(
              selectedDeviceId: _selectedDeviceId,
              onChanged: (id) => setState(() => _selectedDeviceId = id),
            ),
          ),
        ),
        const SizedBox(height: 12),

        // 3) 日期
        _field(
          controller: _dateCtrl,
          label: '日期（YYYYMMDD）',
          hint: '例如：20260208',
          keyboardType: TextInputType.number,
        ),
        const SizedBox(height: 12),

        // 4) 事项
        _field(controller: _itemCtrl, label: '事项（必填）', hint: '例如：更换机油/保养/维修'),
        const SizedBox(height: 12),

        // 5) 金额
        _field(
          controller: _amountCtrl,
          label: '金额（元）',
          hint: '例如：980.0',
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
        ),
        const SizedBox(height: 12),

        // 6) 备注
        _field(controller: _noteCtrl, label: '备注（可填）', hint: '例如：含工时/含配件'),
        const SizedBox(height: 14),

        // 7) 底部按钮（与 Timing/Fuel/Account 统一）
        Row(
          children: [
            TextButton(
              onPressed: _submitting ? null : widget.onCancel,
              child: const Text('取消'),
            ),
            const Spacer(),
            FilledButton(
              onPressed: _submitting ? null : _submit,
              child: Text(_submitting ? '保存中...' : '确定'),
            ),
          ],
        ),
      ],
    );
  }
}
