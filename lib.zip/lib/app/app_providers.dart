import 'package:provider/provider.dart';
import 'package:provider/single_child_widget.dart';

import '../features/account/state/account_store.dart';
import '../features/account/state/account_payment_store.dart';
import '../features/account/state/project_rate_store.dart';
import '../features/device/state/device_store.dart';
import '../features/fuel/state/fuel_store.dart';
import '../features/maintenance/state/maintenance_store.dart';
import '../features/timing/state/timing_store.dart';

class AppProviders {
  static List<SingleChildWidget> build() {
    return [
      ChangeNotifierProvider<DeviceStore>(create: (_) => DeviceStore()),
      ChangeNotifierProvider<TimingStore>(create: (_) => TimingStore()),
      ChangeNotifierProvider<FuelStore>(create: (_) => FuelStore()),
      ChangeNotifierProvider<MaintenanceStore>(
        create: (_) => MaintenanceStore(),
      ),
      ChangeNotifierProvider<AccountPaymentStore>(
        create: (_) => AccountPaymentStore(),
      ),
      ChangeNotifierProvider<AccountStore>(create: (_) => AccountStore()),
      ChangeNotifierProvider<ProjectRateStore>(create: (_) => ProjectRateStore()),
    ];
  }
}
