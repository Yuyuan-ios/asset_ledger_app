import 'package:flutter/material.dart';

class AccountTokens {
  // ===== 账户页：页面容器与整体间距（对齐计时页）=====
  static const double homeMaxContainerWidthTrigger = 420; // 宽屏触发阈值
  static const double homeFixedContentWidth = 393; // 宽屏固定内容宽度
  static const double homePageHorizontalPadding = 10; // 页面左右内边距
  static const double homeTopGap = 0; // 顶部安全区到首卡片的间距

  // ===== 账户页：总览卡片 =====
  static const double overviewCardHeight = 300; // 总览卡片高度
  static const double overviewCardRadius = 12; // 总览卡片圆角
  static const double overviewCardBorderWidth = 1; // 总览卡片边框宽度
  static const double overviewCardPaddingLeft = 12; // 总览卡片左内边距
  static const double overviewCardPaddingTop = 4; // 总览卡片上内边距
  static const double overviewCardPaddingRight = 12; // 总览卡片右内边距
  static const double overviewCardPaddingBottom = 6; // 总览卡片下内边距
  static const double overviewTitleLetterSpacing = 8; // 总览标题字间距
  static const double overviewDividerThickness = 1; // 总览标题分割线厚度

  // ===== 账户页：总览卡片中部（圆环图 + 设备列表）=====
  static const double overviewMiddleTopGap = 6; // 标题到中部图表间距
  static const double overviewChartSize = 120; // 圆环图直径（对齐饼图）
  static const double overviewChartStroke = 20; // 圆环图线宽（加粗）
  static const double overviewChartListGap = 12; // 圆环图与列表间距
  static const double overviewLeftColumnWidth = 140; // 左侧图表列固定宽度（上下对齐）
  static const double overviewLegendDotSize = 8; // 设备色块圆点
  static const double overviewLegendDotGap = 6; // 色块与标题间距
  static const double overviewLegendRowGap = 6; // 设备行间距
  static const double overviewLegendNameSize = 13; // 设备名字号
  static const double overviewLegendValueSize = 13; // 金额字号

  static const double overviewRightPaddingTop = 8; // 右侧文案区上内边距
  static const double overviewRightPaddingRight = 2; // 右侧文案区右内边距
  static const double overviewRightPaddingBottom = 0; // 右侧文案区下内边距
  static const double overviewRightPaddingLeft = 20; // 右侧文案区左内边距
  static const double overviewSummaryTopPadding = 8; // 总应收区域距容器顶部内边距

  // ===== 账户页：总览卡片底部饼图 =====
  static const double overviewPieSize = 120; // 饼图直径
  static const double overviewPieTopGap = 4; // 中部到饼图上方间距
  static const Color overviewPieReceived = Color(0xFF1F5AA8); // 已实收占比（蓝）
  static const Color overviewPieRemaining = Color.fromARGB(
    255,
    182,
    24,
    24,
  ); // 剩余占比（红，降低20%）
  static const double overviewPieGapRadians = 0.03; // 饼图分隔角度
  static const double overviewPieLabelSize = 16; // 饼图百分比字号
  static const FontWeight overviewPieLabelWeight = FontWeight.w400; // 饼图百分比字重
  static const double overviewPieLabelRadiusRatio = 0.6; // 百分比文字半径比例
  static const double overviewPieLabelMinRatio = 0.15; // 小于该比例不显示文字

  static const List<Color> overviewChartPalette = <Color>[
    Color(0xFF5AA9F8),
    Color(0xFF4C6EF5),
    Color(0xFFFFC046),
    Color(0xFFB25CFF),
    Color(0xFF9AA0A6),
  ];

  // ===== 账户页：项目列表标题区（对齐计时页“最近记录”）=====
  static const double projectTitleTopGap = 12; // 总览卡片与标题区间距
  static const double projectListTopGap = 8; // 标题区与项目列表间距
  static const double projectTitleFontSize = 18; // 标题字号
  static const double projectTitleLineHeight = 1; // 标题行高
  static const FontWeight projectTitleWeight = FontWeight.w400; // 标题字重

  // ===== 账户页：项目卡片 =====
  static const double projectCardRadius = 0; // 项目卡片圆角

  // ===== 账户页：筛选按钮 =====
  static const double projectFilterRightInset = 20; // 筛选按钮右侧内边距
}
