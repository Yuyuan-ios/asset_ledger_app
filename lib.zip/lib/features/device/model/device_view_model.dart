class DeviceViewModel {
  const DeviceViewModel();
}
