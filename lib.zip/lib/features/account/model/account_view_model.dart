class AccountViewModel {
  const AccountViewModel();
}
