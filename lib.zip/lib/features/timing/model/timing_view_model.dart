class TimingViewModel {
  const TimingViewModel();
}
