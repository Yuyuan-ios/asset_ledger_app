import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../data/models/device.dart';
import '../../../data/models/timing_record.dart';
import '../../../store/device_store.dart';
import '../../../features/timing/controller/timing_controller.dart';
import 'content/timing_detail_content.dart';
import 'widgets/card_main_chart.dart';
import '../../../presentation/pages/timing/widgets/records_title.dart';
import '../../../presentation/pages/timing/widgets/section_header.dart';
import '../../../presentation/pages/timing/widgets/section_recent_records.dart';
import '../../../presentation/sheets/app_bottom_sheet_shell.dart';
import '../../../presentation/theme/tokens/core_tokens.dart';
import '../../../presentation/theme/tokens/sheet_tokens.dart';
import '../../../presentation/theme/tokens/timing_tokens.dart';
import '../../../presentation/utils/device_label.dart';
import '../../../presentation/widgets/app_confirm_dialog.dart';

class TimingPage extends StatefulWidget {
  const TimingPage({super.key});

  @override
  State<TimingPage> createState() => _TimingPageState();
}

class _TimingPageState extends State<TimingPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final deviceStore = context.read<DeviceStore>();
      final timingStore = context.read<TimingStore>();
      await deviceStore.loadAll();
      await timingStore.loadAll();
    });
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), duration: AppDurations.snackBar),
    );
  }

  Future<void> _openTimingEditor({TimingRecord? editing}) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: false,
      backgroundColor: Colors.transparent,
      builder: (_) {
        return AppBottomSheetShell(
          title: editing == null ? '新建计时' : '编辑计时',
          initialHeightFactor: SheetTokens.heightFactor,
          radius: SheetTokens.radius,
          scrollable: false,
          contentPadding: EdgeInsets.zero,
          child: TimingDetailContent(
            editing: editing,
            onCancel: () => Navigator.of(context).pop(),
            onToast: _toast,
            onSubmit: (record) async {
              final store = context.read<TimingStore>();
              await store.save(record);
              if (!mounted) return;

              if (store.error != null) {
                _toast('保存失败：${store.error}');
                return;
              }

              _toast('已保存');
              Navigator.of(context).pop();
            },
          ),
        );
      },
    );
  }

  Future<bool> _confirmDeleteRecord(TimingRecord record) async {
    if (record.id == null) return false;

    return showAppConfirmDialog(
      context: context,
      title: '删除记录',
      content:
          '⚠️ 删除此记录将产生以下影响：\n\n'
          '• 燃油页：工时模式下对应的燃油效率数据\n\n'
          '• 账户页：对应项目的统计数据\n\n'
          '确定删除这条记录吗？',
      confirmText: '删除',
    );
  }

  Future<bool> _deleteRecord(TimingRecord record) async {
    if (record.id == null) return false;
    if (!mounted) return false;

    final store = context.read<TimingStore>();
    await store.deleteById(record.id!);
    if (!mounted) return false;
    if (store.error != null) {
      _toast('删除失败：${store.error}');
      return false;
    } else {
      _toast('已删除');
      return true;
    }
  }

  @override
  Widget build(BuildContext context) {
    final timingStore = context.watch<TimingStore>();
    final deviceStore = context.watch<DeviceStore>();

    final loading = timingStore.loading || deviceStore.loading;
    final error = timingStore.error ?? deviceStore.error;
    final deviceById = <int, Device>{};
    for (final d in deviceStore.allDevices) {
      final id = d.id;
      if (id == null) continue;
      deviceById[id] = d;
    }
    final deviceIndexById = DeviceLabel.indexMapById(deviceStore.allDevices);

    return Scaffold(
      backgroundColor: AppColors.scaffoldBg,
      body: SafeArea(
        bottom: false,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final contentWidth =
                constraints.maxWidth > TimingTokens.homeMaxContainerWidthTrigger
                ? TimingTokens.homeFixedContentWidth
                : constraints.maxWidth;

            return Align(
              alignment: Alignment.topCenter,
              child: SizedBox(
                width: contentWidth,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(
                    TimingTokens.homePageHorizontalPadding,
                    0,
                    TimingTokens.homePageHorizontalPadding,
                    0,
                  ),
                  child: Column(
                    children: [
                      SectionHeader(onAdd: () => _openTimingEditor()),
                      const SizedBox(height: TimingTokens.homeHeaderBottomGap),
                      Expanded(
                        child: SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (loading)
                                const Padding(
                                  padding: EdgeInsets.only(
                                    bottom: TimingTokens.homeLoadingBottomGap,
                                  ),
                                  child: LinearProgressIndicator(minHeight: 2),
                                ),
                              if (error != null && error.trim().isNotEmpty)
                                Padding(
                                  padding: const EdgeInsets.only(
                                    bottom: TimingTokens.homeErrorBottomGap,
                                  ),
                                  child: Text(
                                    error,
                                    style: const TextStyle(
                                      color: Colors.red,
                                      fontSize: TimingTokens.homeErrorFontSize,
                                    ),
                                  ),
                                ),
                              const CardMainChart(),
                              const SizedBox(
                                height: TimingTokens.homeChartTopGap,
                              ),
                              RecordsTitle(count: timingStore.records.length),
                              const SizedBox(
                                height: TimingTokens.homeRecordsTitleTopGap,
                              ),
                              SectionRecentRecords(
                                records: timingStore.records,
                                deviceById: deviceById,
                                deviceIndexById: deviceIndexById,
                                onTapRecord: (r) =>
                                    _openTimingEditor(editing: r),
                                onConfirmDeleteRecord: _confirmDeleteRecord,
                                onDeleteRecord: _deleteRecord,
                              ),
                              const SizedBox(
                                height: TimingTokens.homeBottomGap,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
