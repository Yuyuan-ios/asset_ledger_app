class FuelViewModel {
  const FuelViewModel();
}
