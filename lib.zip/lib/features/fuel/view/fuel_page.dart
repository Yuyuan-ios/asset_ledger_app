import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../data/models/fuel_log.dart';
import '../../../store/device_store.dart';
import '../../../store/fuel_store.dart';
import '../../timing/controller/timing_controller.dart';
import 'content/fuel_detail_content.dart';
import 'widgets/fuel_efficiency_summary.dart';
import 'widgets/fuel_recent_records_section.dart';
import 'widgets/fuel_summary_card.dart';
import 'widgets/fuel_supplier_filter.dart';
import '../../../presentation/pages/timing/widgets/section_header.dart';
import '../../../presentation/sheets/app_bottom_sheet_shell.dart';
import '../../../presentation/theme/tokens/core_tokens.dart';
import '../../../presentation/theme/tokens/fuel_tokens.dart';
import '../../../presentation/utils/device_label.dart';
import '../../../presentation/utils/format_utils.dart';
import '../../../presentation/widgets/app_confirm_dialog.dart';
import '../../../presentation/widgets/device_avatar.dart';

class FuelPage extends StatefulWidget {
  const FuelPage({super.key});

  @override
  State<FuelPage> createState() => _FuelPageState();
}

class _FuelPageState extends State<FuelPage> {
  final _supplierFilterCtrl = TextEditingController();
  String _supplierFilter = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final deviceStore = context.read<DeviceStore>();
      final timingStore = context.read<TimingStore>();
      final fuelStore = context.read<FuelStore>();
      await deviceStore.loadAll();
      await timingStore.loadAll();
      await fuelStore.loadAll();
    });
  }

  @override
  void dispose() {
    _supplierFilterCtrl.dispose();
    super.dispose();
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), duration: AppDurations.snackBar),
    );
  }

  Future<void> _openFuelEditor({FuelLog? editing}) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return AppBottomSheetShell(
          title: editing == null ? '新增燃油' : '编辑燃油',
          scrollable: false,
          child: FuelDetailContent(
            editing: editing,
            onCancel: () => Navigator.of(ctx).pop(),
            onToast: _toast,
            onSubmit: (log) async {
              final store = context.read<FuelStore>();
              if (log.id == null) {
                await store.insert(log);
              } else {
                await store.update(log);
              }

              if (!mounted) return;
              if (store.error != null) {
                _toast('保存失败：${store.error}');
                return;
              }

              _toast('已保存');
              if (!ctx.mounted) return;
              Navigator.of(ctx).pop();
            },
          ),
        );
      },
    );
  }

  Future<bool> _confirmDelete(FuelLog log) async {
    if (log.id == null) return false;
    final ok = await showAppConfirmDialog(
      context: context,
      title: '确认删除？',
      content: '删除后不可恢复。',
      confirmText: '删除',
    );
    return ok == true;
  }

  Future<bool> _delete(FuelLog log) async {
    if (log.id == null) return false;
    if (!mounted) return false;

    final store = context.read<FuelStore>();
    await store.deleteById(log.id!);

    if (!mounted) return false;
    if (store.error != null) {
      _toast('删除失败：${store.error}');
      return false;
    } else {
      _toast('已删除');
      return true;
    }
  }

  List<FuelLog> _filteredLogs(List<FuelLog> logs) {
    if (_supplierFilter.isEmpty) return logs;
    return logs.where((e) => e.supplier.contains(_supplierFilter)).toList();
  }

  @override
  Widget build(BuildContext context) {
    final fuelStore = context.watch<FuelStore>();
    final deviceStore = context.watch<DeviceStore>();
    final timingStore = context.watch<TimingStore>();

    final loading =
        fuelStore.loading || deviceStore.loading || timingStore.loading;
    final err = fuelStore.error ?? deviceStore.error ?? timingStore.error;

    final nowYmd = FormatUtils.ymdFromDate(DateTime.now());
    final supplier = _supplierFilter.trim().isEmpty
        ? null
        : _supplierFilter.trim();
    final yearSummary = fuelStore.currentYearSummary(
      nowYmd: nowYmd,
      supplier: supplier,
    );
    final yearSummaryTitle = supplier == null ? '本年度总消耗' : '本年度（$supplier）';

    final byDevice = fuelStore.efficiencyByDeviceAllTime(timingStore.records);
    final filteredLogs = _filteredLogs(fuelStore.logs);
    final deviceIndexById = DeviceLabel.indexMapById(deviceStore.allDevices);

    return Scaffold(
      backgroundColor: AppColors.scaffoldBg,
      body: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: () => FocusScope.of(context).unfocus(),
        child: SafeArea(
          bottom: false,
          child: LayoutBuilder(
            builder: (context, constraints) {
              final contentWidth =
                  constraints.maxWidth > FuelTokens.homeMaxContainerWidthTrigger
                  ? FuelTokens.homeFixedContentWidth
                  : constraints.maxWidth;

              return Align(
                alignment: Alignment.topCenter,
                child: SizedBox(
                  width: contentWidth,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(
                      FuelTokens.homePageHorizontalPadding,
                      0,
                      FuelTokens.homePageHorizontalPadding,
                      0,
                    ),
                    child: Column(
                      children: [
                        SectionHeader(
                          title: '燃油',
                          onAdd: () => _openFuelEditor(),
                        ),
                        const SizedBox(height: FuelTokens.homeHeaderBottomGap),
                        Expanded(
                          child: SingleChildScrollView(
                            child: Padding(
                              padding: const EdgeInsets.all(
                                FuelTokens.homeContentPadding,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  if (loading) ...[
                                    const LinearProgressIndicator(),
                                    const SizedBox(
                                      height: FuelTokens.homeLoadingBottomGap,
                                    ),
                                  ],
                                  if (err != null) ...[
                                    Text(
                                      err,
                                      style: const TextStyle(color: Colors.red),
                                    ),
                                    const SizedBox(
                                      height: FuelTokens.homeErrorBottomGap,
                                    ),
                                  ],

                                  FuelSummaryCard(
                                    height: FuelTokens.efficiencyCardHeight,
                                    child: Padding(
                                      padding: const EdgeInsets.all(
                                        FuelTokens.summaryInnerPadding,
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Expanded(
                                            child: FuelEfficiencySummary(
                                              byDevice: byDevice,
                                              deviceNameOf: (id) {
                                                final d = deviceStore.findById(
                                                  id,
                                                );
                                                return d?.name ??
                                                    '设备$id（已停用/不存在）';
                                              },
                                            ),
                                          ),
                                          const SizedBox(
                                            height: FuelTokens.summaryInnerGap,
                                          ),
                                          Row(
                                            children: [
                                              Text(
                                                yearSummaryTitle,
                                                style: const TextStyle(
                                                  fontSize: FuelTokens
                                                      .summaryTotalLabelSize,
                                                  fontWeight: FontWeight.w800,
                                                ),
                                              ),
                                              const SizedBox(
                                                width: FuelTokens
                                                    .summaryTotalValueLeftGap,
                                              ),
                                              Expanded(
                                                child: Text(
                                                  '${FormatUtils.liters(yearSummary.liters)} L / ${FormatUtils.money(yearSummary.cost)}',
                                                  textAlign: TextAlign.right,
                                                  style: const TextStyle(
                                                    fontSize: FuelTokens
                                                        .summaryTotalValueSize,
                                                    fontWeight: FontWeight.w800,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: FuelTokens.homeSectionGap,
                                  ),

                                  FuelSupplierFilter(
                                    controller: _supplierFilterCtrl,
                                    suggestionsBuilder:
                                        fuelStore.supplierSuggestions,
                                    onChanged: (v) => setState(
                                      () => _supplierFilter = v.trim(),
                                    ),
                                    onSelected: (v) {
                                      _supplierFilterCtrl.text = v;
                                      setState(
                                        () => _supplierFilter = v.trim(),
                                      );
                                    },
                                  ),
                                  const SizedBox(
                                    height: FuelTokens.homeSectionGap,
                                  ),

                                  FuelRecentRecordsSection(
                                    logs: filteredLogs,
                                    leadingBuilder: (log) {
                                      final d = deviceStore.findById(
                                        log.deviceId,
                                      );
                                      if (d == null) {
                                        return const CircleAvatar(
                                          radius: 18,
                                          child: Text('?'),
                                        );
                                      }
                                      return DeviceAvatar(device: d);
                                    },
                                    titleBuilder: (log) => log.supplier,
                                    subtitleBuilder: (log) =>
                                        deviceIndexById[log.deviceId] ?? '?',
                                    onTap: (log) =>
                                        _openFuelEditor(editing: log),
                                    onConfirmDelete: _confirmDelete,
                                    onDelete: _delete,
                                  ),

                                  const SizedBox(
                                    height: FuelTokens.homeListBottomGap,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
