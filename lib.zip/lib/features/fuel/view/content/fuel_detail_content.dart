// ==============================================================================
// 📁 文件说明：燃油弹窗内容 (fuel_detail_content.dart)
//
// 设计目标：
// 1) 作为 BottomSheet 的内容区域（配合 AppBottomSheetShell 使用）
// 2) 负责“新增/编辑燃油”的表单与校验
// 3) 不直接操作 Store / 不 pop：统一走回调（与 Account 统一）
// ==============================================================================

// =====================================================================
// 一、导入依赖
// =====================================================================

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../core/foundation/spacing.dart';
import '../../../../data/models/fuel_log.dart';
import '../../../../patterns/layout/bottom_action_bar.dart';
import '../../../../store/device_store.dart';
import '../../../../store/fuel_store.dart';
import '../../../../presentation/theme/tokens/core_tokens.dart';
import '../../../../presentation/theme/tokens/sheet_tokens.dart';
import '../../../../presentation/utils/format_utils.dart';
import '../../../../presentation/widgets/auto_suggest_field.dart';
import '../../../../presentation/widgets/device_picker.dart';
import '../../../../presentation/widgets/sheet_date_field.dart';
import '../../../../presentation/widgets/sheet_date_picker_dialog.dart';

// =====================================================================
// 二、FuelDetailContent
// =====================================================================

class FuelDetailContent extends StatefulWidget {
  const FuelDetailContent({
    super.key,
    this.editing,
    required this.onCancel,
    required this.onToast,
    required this.onSubmit,
  });

  /// editing != null：编辑；否则新建
  final FuelLog? editing;

  /// 取消（由 Page 负责 pop）
  final VoidCallback onCancel;

  /// toast（统一走 Page 的 toast 体系）
  final void Function(String msg) onToast;

  /// 提交（Content 只组装 FuelLog，Page 负责落库+toast+pop）
  final Future<void> Function(FuelLog log) onSubmit;

  @override
  State<FuelDetailContent> createState() => _FuelDetailContentState();
}

// =====================================================================
// 三、State：表单 + 校验 + 组装
// =====================================================================

class _FuelDetailContentState extends State<FuelDetailContent> {
  // -------------------------------------------------------------------
  // 3.1 表单控制器
  // -------------------------------------------------------------------

  final _dateCtrl = TextEditingController();
  final _supplierCtrl = TextEditingController();
  final _litersCtrl = TextEditingController();
  final _costCtrl = TextEditingController();

  // -------------------------------------------------------------------
  // 3.2 业务状态
  // -------------------------------------------------------------------

  int? _selectedDeviceId;
  bool _submitting = false;

  // =====================================================================
  // 四、生命周期：回填/初始化
  // =====================================================================

  @override
  void initState() {
    super.initState();

    final editing = widget.editing;
    if (editing == null) {
      _dateCtrl.text = FormatUtils.todayDisplayDate();
      _applyDefaultDeviceForCreate();
      _supplierCtrl.text = _latestSupplier();
      _litersCtrl.clear();
      _costCtrl.clear();
    } else {
      _selectedDeviceId = editing.deviceId;
      _dateCtrl.text = FormatUtils.date(editing.date);
      _supplierCtrl.text = editing.supplier;
      _litersCtrl.text = FormatUtils.liters(editing.liters);
      _costCtrl.text = FormatUtils.moneyNumber(editing.cost);
    }
  }

  String _latestSupplier() {
    final logs = context.read<FuelStore>().logs;
    for (final r in logs) {
      final s = r.supplier.trim();
      if (s.isNotEmpty) return s;
    }
    return '';
  }

  void _applyDefaultDeviceForCreate() {
    if (widget.editing != null || _selectedDeviceId != null) return;

    final deviceStore = context.read<DeviceStore>();
    final activeDevices = deviceStore.activeDevices.where((d) => d.id != null);
    if (activeDevices.isEmpty) return;

    final fuelStore = context.read<FuelStore>();

    int? defaultDeviceId;
    for (final r in fuelStore.logs) {
      final d = deviceStore.findById(r.deviceId);
      if (d != null && d.isActive) {
        defaultDeviceId = r.deviceId;
        break;
      }
    }

    defaultDeviceId ??= activeDevices.first.id;
    if (defaultDeviceId == null) return;

    final device = deviceStore.findById(defaultDeviceId);
    if (device == null || !device.isActive) return;

    _selectedDeviceId = defaultDeviceId;
  }

  @override
  void dispose() {
    _dateCtrl.dispose();
    _supplierCtrl.dispose();
    _litersCtrl.dispose();
    _costCtrl.dispose();
    super.dispose();
  }

  // =====================================================================
  // 五、工具：解析/校验
  // =====================================================================

  double? _parseDouble(String s) => double.tryParse(s.trim());

  Future<void> _pickDate() async {
    final fallback = FormatUtils.parseDate(FormatUtils.todayDisplayDate())!;
    final currentYmd = FormatUtils.parseDate(_dateCtrl.text) ?? fallback;
    final initialDate = FormatUtils.dateFromYmd(currentYmd);

    final picked = await showSheetDatePickerDialog(
      context: context,
      initialDate: initialDate,
    );

    if (picked == null || !mounted) return;
    final ymd = FormatUtils.ymdFromDate(picked);
    setState(() => _dateCtrl.text = FormatUtils.date(ymd));
  }

  // =====================================================================
  // 六、提交：只组装 FuelLog + 调回调
  // =====================================================================

  Future<void> _submit() async {
    if (_submitting) return;

    // 6.1 device 必选
    final deviceId = _selectedDeviceId;
    if (deviceId == null) {
      widget.onToast('保存失败：请先选择设备');
      return;
    }

    // 6.2 新建态：不允许选停用设备（编辑态允许回显历史）
    final device = context.read<DeviceStore>().findById(deviceId);
    if (device == null) {
      widget.onToast('设备不存在（id=$deviceId），请先去设备页检查');
      return;
    }
    if (widget.editing == null && !device.isActive) {
      widget.onToast('该设备已停用，不能用于新建燃油记录');
      return;
    }

    // 6.3 日期
    final date = FormatUtils.parseDate(_dateCtrl.text);
    if (date == null || date <= 0) {
      widget.onToast(FormatUtils.ymdInvalidMsg);
      return;
    }

    // 6.4 供应人必填
    final supplier = _supplierCtrl.text.trim();
    if (supplier.isEmpty) {
      widget.onToast('保存失败：供应人必填');
      return;
    }

    // 6.5 liters / cost
    final liters = _parseDouble(_litersCtrl.text);
    if (liters == null || liters <= 0) {
      widget.onToast('保存失败：加油量必须是 > 0 的数字');
      return;
    }

    final cost = _parseDouble(_costCtrl.text);
    if (cost == null || cost < 0) {
      widget.onToast('保存失败：金额必须是 >= 0 的数字');
      return;
    }

    // 6.6 组装 FuelLog（不落库、不 pop）
    final log = FuelLog(
      id: widget.editing?.id,
      deviceId: deviceId,
      date: date,
      supplier: supplier,
      liters: liters,
      cost: cost,
    );

    setState(() => _submitting = true);
    await widget.onSubmit(log);
    if (mounted) setState(() => _submitting = false);
  }

  // =====================================================================
  // 七、UI 小组件
  // =====================================================================

  Widget _field({
    required TextEditingController controller,
    required String label,
    TextInputType? keyboardType,
    String? hint,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      style: const TextStyle(
        fontSize: SheetTokens.fieldTextSize,
        color: AppColors.sheetTextPrimary,
      ),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(
          fontSize: SheetTokens.fieldLabelSize,
          color: AppColors.sheetHint,
        ),
        floatingLabelBehavior: FloatingLabelBehavior.always,
        hintText: hint,
        hintStyle: const TextStyle(
          fontSize: SheetTokens.fieldTextSize,
          color: AppColors.sheetHint,
        ),
        filled: true,
        fillColor: AppColors.sheetFieldBackground,
        constraints: const BoxConstraints(minHeight: SheetTokens.fieldHeight),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: SheetTokens.fieldContentHPadding,
          vertical: SheetTokens.fieldContentVPadding,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(SheetTokens.fieldRadius),
          borderSide: const BorderSide(
            color: AppColors.sheetFieldBorder,
            width: SheetTokens.fieldBorderWidth,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(SheetTokens.fieldRadius),
          borderSide: const BorderSide(
            color: AppColors.sheetFieldBorder,
            width: SheetTokens.fieldBorderWidth,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(SheetTokens.fieldRadius),
          borderSide: const BorderSide(
            color: AppColors.sheetFieldBorder,
            width: SheetTokens.fieldBorderWidth,
          ),
        ),
      ),
    );
  }

  // =====================================================================
  // 八、build：表单内容
  // =====================================================================

  @override
  Widget build(BuildContext context) {
    final store = context.watch<FuelStore>(); // 仅用于供应人联想候选

    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () => FocusScope.of(context).unfocus(),
      child: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(
                  SheetTokens.outerHPadding,
                  0,
                  SheetTokens.outerHPadding,
                  0,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // 1) 设备
                    DevicePicker(
                      selectedDeviceId: _selectedDeviceId,
                      onChanged: (id) => setState(() => _selectedDeviceId = id),
                    ),
                    const SizedBox(height: AppSpace.md),

                    // 2) 日期
                    SheetDateField(
                      controller: _dateCtrl,
                      onPickDate: _pickDate,
                    ),
                    const SizedBox(height: AppSpace.md),

                    // 3) 供应人（必填，联想）
                    AutoSuggestField(
                      controller: _supplierCtrl,
                      label: '供应人（必填）',
                      hint: '例如：中石化 / 老王油品',
                      suggestionsBuilder: (q) =>
                          store.supplierSuggestions(q, limit: 9999),
                      onSelected: (v) => _supplierCtrl.text = v,
                    ),
                    const SizedBox(height: AppSpace.md),

                    // 4) 加油量
                    _field(
                      controller: _litersCtrl,
                      label: '加油量（升）',
                      hint: '例如：120.0',
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                    ),
                    const SizedBox(height: AppSpace.md),

                    // 5) 金额
                    _field(
                      controller: _costCtrl,
                      label: '金额（元）',
                      hint: '例如：980.0',
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: SheetTokens.footerTopGap),
          BottomActionBar(
            onCancel: widget.onCancel,
            onConfirm: _submit,
            confirmText: _submitting ? '保存中...' : '确定',
            enabled: !_submitting,
          ),
        ],
      ),
    );
  }
}
