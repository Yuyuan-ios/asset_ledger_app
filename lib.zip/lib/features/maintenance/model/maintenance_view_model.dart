class MaintenanceViewModel {
  const MaintenanceViewModel();
}
